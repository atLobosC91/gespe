<h1>Dashboard Supervisor</h1>
<p>Bienvenido, <?= $this->session->get('nombre'); ?>. Tienes acceso limitado.</p>
