
<h1>Dashboard Administrador</h1>
<p>Bienvenido, <?= $this->session->get('nombre'); ?>. Tienes acceso total.</p>
