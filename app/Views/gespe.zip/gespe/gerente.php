<h1>Dashboard Gerente</h1>
<p>Bienvenido, <?= $this->session->get('nombre'); ?>. Tienes acceso limitado.</p>
