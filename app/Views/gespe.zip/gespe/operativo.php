<h1>Dashboard Operativo</h1>
<p>Bienvenido, <?= $this->session->get('nombre'); ?>. Tienes acceso limitado.</p>
